#include "circBuffer.h"
#include "sine.h"
#include <iostream>

class Delay
{
public:
  CircBuffer buffer;
  Sine sine;

  Delay(float samplerate, float delaytime, float feedback,
    float lfoFreq, float lfoDepth, float drywet, int framesize);
  ~Delay();

  void setDelayTime(float delayTime);
  void setFeedback(float feedback);
  void setLfoFreq(float lfoFreq);
  void setLfoDepth(float lfoDepth);
  void setDryWet(float drywet);
  float getInput(float input);
  float getSample();

  void process(float* inBuf, float* outBuf);

protected:
  int numSamplesDelay;
  float samplerate;
  float delayTime;
  float feedback;
  float lfoFreq;
  float lfoDepth;
  float drywet;
  float input;
  float output;

  int framesize;
};
