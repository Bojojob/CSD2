#ifndef fft1D_H
#define fft1D_H

#include <fftw3.h>
#include <vector>
#include <complex.h>

class fft1D
{
public:
  fft1D(int N, int flags);
  ~fft1D();

  void transform();
  void itransform();


  double* outRe();
  void inRe(double* inRe);

  void inVector(std::vector<double> inRe);
  std::vector<double> outVector();

  std::vector<std::vector<double>> outCPX();
  void inCPX(std::vector<double>, std::vector<double>);


protected:
  int N;
  int flags;

  double* in;
  double* out;
  fftw_complex* out_cpx;
  fftw_plan p;
  fftw_plan ip;

  double* floutRe;
  double* floutIm;

};

#endif
