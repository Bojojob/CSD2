#ifndef FFTAvg_H
#define FFTAvg_H

#include "CVAM/processFunction.h"
#include "CVAM/fft1D.h"
#include <vector>


class fftAvg : public processFunction
{
public:
  fftAvg(fft1D* fft, int amt, int N);
  ~fftAvg();

  std::vector<double> process(std::vector<double> input);
  void setAmt(int newamt);

private:
  fft1D* fft;

  std::vector<double> output;
  std::vector<double> tempRe;
  std::vector<double> tempIm;

  int amt;
  int N;


  std::vector<std::vector<double>> matrixRe;
  std::vector<std::vector<double>> matrixIm;

};


#endif
