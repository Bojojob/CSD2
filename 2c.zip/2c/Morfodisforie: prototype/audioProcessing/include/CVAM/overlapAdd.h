#ifndef OVERLAPADD_H
#define OVERLAPADD_H

#include <complex>
#include <vector>
#include <math.h>
#include <algorithm>
#include <numeric>
#include "CVAM/processFunction.h"

class overlapAdd{
public:
  overlapAdd(unsigned int buffersize, processFunction* funcObj);
  overlapAdd();
  ~overlapAdd();

  void process(float* inBuf, float* outBuf); // processes


private:
  unsigned int buffersize;
  unsigned int hopsize;

  unsigned int readPos;


  processFunction* funcObj;

  std::vector<double> w; // hann window
  std::vector<double> result;
  std::vector<double> prevResult;
  std::vector<double> partialResult;

  std::vector<double> tempin;
  std::vector<double> tempout;

  std::vector<double> bufferHistory;


};

#endif // OVERLAPADD_H
