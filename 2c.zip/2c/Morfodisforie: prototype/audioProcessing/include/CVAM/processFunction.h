#ifndef processFunction_H
#define processFunction_H

#include <vector>

class processFunction
{
public:
  processFunction();
  virtual ~processFunction();

  virtual std::vector<double> process(std::vector<double> input);
};


#endif
