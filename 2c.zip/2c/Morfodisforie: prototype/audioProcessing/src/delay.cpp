#include <thread>
#include <iostream>
#include "CVAM/delay.h"
#include "math.h"

// Delaytime input in ms, feedback value between 0 - 1, drywet value between 0 - 1.
Delay::Delay(float samplerate, float delayTime, float feedback,
  float lfoFreq, float lfoDepth, float drywet, int framesize)  {
  this->samplerate = samplerate;
  this->delayTime = delayTime;
  this->feedback = feedback;
  this->drywet = drywet;
  this->lfoFreq = lfoFreq;
  this->lfoDepth = lfoDepth;
  this->framesize = framesize;
  //Initally sets to maximum buffer length.
  //Buffer must be twice as long as desired delay.
  numSamplesDelay = samplerate * (delayTime / 1000);
  buffer.resetSize(numSamplesDelay * 2);
  buffer.setDistanceRW(numSamplesDelay);
  //Modulator settings.
  sine.setSamplerate(samplerate);
  sine.setFrequency(lfoFreq);
}

Delay::~Delay()
{

}

void Delay::setDelayTime(float delayTime)
{
  this->delayTime = delayTime;
  numSamplesDelay = samplerate * (delayTime / 1000);
}

void Delay::setFeedback(float feedback)
{
  if (feedback < 1)  {
    this->feedback = feedback;
  }
}

void Delay::setLfoFreq(float lfoFreq)
{
  this->lfoFreq = lfoFreq;
  sine.setFrequency(lfoFreq);
}

void Delay::setLfoDepth(float lfoDepth)
{
  this->lfoDepth = lfoDepth;
}

//Setter for setting volume of the wet and dry signal, should be set between 0-1
void Delay::setDryWet(float drywet)
{
  if (drywet <= 1)  {
    this->drywet = drywet;
  }
}

float Delay::getInput(float input) {
  this->input = input;
}

//Process method - Takes input, writes to buffer and modulates readhead position. Returns output.
float Delay::getSample()
{
  //buffer.logAllSettings();
  float mod = sine.getSample() * lfoDepth;
  if (numSamplesDelay + mod > 10 ) {
    buffer.setDistanceRW(numSamplesDelay + mod);
  }
  //std::cout << numSamplesDelay + mod << "\n";
  sine.tick();
  buffer.write(input + output * feedback);
  buffer.incrWriteH();;
  output = buffer.read() * drywet + input * (1-drywet);
  buffer.incrReadH();
  return output;
}

void Delay::process(float* inBuf, float* outBuf){
  for(unsigned int i = 0; i < framesize; i++) {
    getInput(inBuf[i]);
    outBuf[i] = getSample();
  }
};
