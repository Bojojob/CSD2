#include "fftw3.h"
#include "CVAM/fft1D.h"
#include <iostream>
#include <stdlib.h>     /* malloc, free, rand */

#include <tuple>
// http://www.fftw.org/fftw2_doc/fftw_2.html
// N is size of data
// dir is direction FFTW_FORWARD or FFTW_BACKWARD.
// flags is either FFTW_ESTIMATE or FFTW_MEASURE. if initialization time does not matter and transformations are on the same size use FFTW_MEASURE.
fft1D::fft1D(int N, int flags) : N(N)
{

  in = (double*) fftw_malloc(sizeof(double) * N);
  out = (double*) fftw_malloc(sizeof(double) * N);
  out_cpx = (fftw_complex*) fftw_malloc(sizeof(fftw_complex) * N);

  floutRe = (double*) malloc(sizeof(double) * N);
  floutIm = (double*) malloc(sizeof(double) * N);

  p = fftw_plan_dft_r2c_1d(N, in, out_cpx, flags); // forward FFT transform
  ip = fftw_plan_dft_c2r_1d(N, out_cpx, out, flags); // backward FFT transform

};

fft1D::~fft1D()
{
  fftw_destroy_plan(p);
  fftw_destroy_plan(ip);
  fftw_free(in);
  fftw_free(out);
  free(floutRe);
  free(floutIm);
};

void fft1D::inVector(std::vector<double> inRe)
{
  for(int i = 0; i < N; i++)
  {
    in[i] = inRe.at(i);
  }
};
// perform forward transform
void fft1D::transform()
{
  fftw_execute(p);
};

// perform backward transform
void fft1D::itransform()
{
  fftw_execute(ip);
};

std::vector<std::vector<double>> fft1D::outCPX()
{
  std::vector<std::vector<double>> output(2, std::vector<double>(N));
  std::vector<double> outCPXRe(N);
  std::vector<double> outCPXIm(N);
  for(int i = 0; i<N; i++){
    outCPXRe.at(i) = out_cpx[i][0];
    outCPXIm.at(i) = out_cpx[i][1];
  }
  output.at(0) = outCPXRe;
  output.at(1) = outCPXIm;
  return output;
};

// method to take in complex numbers for backward fft transform
void fft1D::inCPX(std::vector<double> inCPXRe, std::vector<double> inCPXIm )
{
  for(int i = 0; i<N; i++){
    out_cpx[i][0] = inCPXRe.at(i);
    out_cpx[i][1] = inCPXIm.at(i);
  }
}

std::vector<double> fft1D::outVector()
{
  std::vector<double> outRe(N);
  for(int i = 0; i < N; i++)
  {
    outRe.at(i) = out[i]/((N+1)/2);
  }
  return outRe;
};

void fft1D::inRe(double* inRe)
{
  for(int i = 0; i < N; i++)
  {
    in[i] = inRe[i];
  }
};

double* fft1D::outRe()
{
  return out;
}
