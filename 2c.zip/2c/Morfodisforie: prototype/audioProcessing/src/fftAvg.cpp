#include "CVAM/fftAvg.h"
#include <iostream>
#include <algorithm>    // std::min_element, std::max_element
#include <bits/stdc++.h>


fftAvg::fftAvg(fft1D* fft, int amt, int N) : fft(fft), amt(amt), N(N) {

  // initialize matrix for memory of FFT information.
  matrixRe.resize(amt);
  for(int i = 0;i <amt;i++)
  {
      matrixRe[i].resize(N);
      for(int j = 0;j < N;j++)
      {
          matrixRe[i][j] = 0.0;
      }//end j for loop
  }//end i for loop
  matrixIm.resize(amt);
  for(int i = 0;i <amt;i++)
  {
      matrixIm[i].resize(N);
      for(int j = 0;j < N;j++)
      {
          matrixIm[i][j] = 0.0;
      }//end j for loop
  }//end i for loop
};

fftAvg::~fftAvg(){};

// change the amount of buffers to save to memory
void fftAvg::setAmt(int newamt){
  if(amt > 1){
    this->amt = newamt;
    matrixRe.resize(amt);
    matrixIm.resize(amt);
    for(int i = 0;i <amt;i++)
    {
        matrixRe[i].resize(N);
        for(int j = 0;j < N;j++)
        {
            matrixRe[i][j] = 0.0;
        }//end j for loop
    }//end i for loop
    matrixIm.resize(amt);
    for(int i = 0;i <amt;i++)
    {
        matrixIm[i].resize(N);
        for(int j = 0;j < N;j++)
        {
            matrixIm[i][j] = 0.0;
        }//end j for loop
    }//end i for loop
  }
}

// returns the average real and complex values of FFT transform of audio input over the last "amt" frames.
std::vector<double> fftAvg::process(std::vector<double> input) {

  output.resize(input.size());
  tempRe.resize(input.size());
  tempIm.resize(input.size());

  std::fill(output.begin(), output.end(), 0.0);
  std::fill(tempRe.begin(), tempRe.end(), 0.0);
  std::fill(tempIm.begin(), tempIm.end(), 0.0);


  fft->inVector(input);
  // to frequency domain
  fft->transform();
  std::vector<std::vector<double>> data = fft->outCPX();

  tempRe = data.at(0);
  tempIm = data.at(1);

  float sum;

  for(int i = 0; i < amt-1; i++){
    matrixRe.at(i) = matrixRe.at(i+1);
  }

  for(int i = 0; i < amt-1; i++){
    matrixIm.at(i) = matrixIm.at(i+1);
  }

  matrixRe.at(amt-1) = tempRe;
  matrixIm.at(amt-1) = tempIm;

  for(int i = 0; i < input.size(); i++){
    sum = 0;
    for(int j = 0; j < amt; j++){
      sum = sum + matrixRe.at(j).at(i);
    }
    tempRe[i] = sum / amt;
  }


  for(int i = 0; i < input.size(); i++){
    sum = 0;
    for(int j = 0; j < amt; j++){
      sum = sum + matrixIm.at(j).at(i);
    }
    tempIm.at(i) = sum / amt;
  }


  fft->inCPX(tempRe, tempIm);
  // back to time domain.
  fft->itransform();

  output = fft->outVector();

  return output;

};
