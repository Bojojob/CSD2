
#include <iostream>
#include <vector>

#include "fftw3.h"

#include "CVAM/processFunction.h"
#include "CVAM/fftAvg.h"

#include "CVAM/overlapAdd.h"
#include "CVAM/jack_module.h"

#include "CVAM/delay.h"


#include <cstring>

#include <ctime>

#include <lo/lo.h>

// Macros for changing parameters with osc messages
float triggerMacro1 = 0;
float triggerMacro2 = 0;

// function definitions of osc handlers for liblo.
void error(int num, const char *m, const char *path);

int generic_handler(const char *path, const char *types, lo_arg ** argv,
                    int argc, void *data, void *user_data);



int main(){
	// create a JackModule instance
	JackModule jack;
	// init the jack, use program name as JACK client name
	jack.init();
  float samplerate = jack.getSamplerate();


  // get buffer size
	int N = jack.getBufferSize();

  // setup and start osc server
	lo_server_thread st = lo_server_thread_new("12345", error);
	lo_server_thread_add_method(st, "/position", "ff", generic_handler, NULL);

	lo_server_thread_start(st);

  // create instance of FFT1D for fftAvg
  fft1D* fft = new fft1D(N, FFTW_ESTIMATE);

  // create instance fftAvg process function
	fftAvg* fftAvgProcess = new fftAvg(fft, 8, N);

  //Initial delay settings. A 9 second delay is set to allocate a large buffer.
  Delay flanger(samplerate, 9000, 0.9, 0.5, 100, 1, N);
  flanger.setDelayTime(5);
  flanger.setLfoFreq(0.5);

  // create instance of overlapAdd with fftAvgProcess as process Function
	overlapAdd fftaverage(N, fftAvgProcess);

  // create a tempBuf to
	float* tempBuf = (float*)malloc(N * sizeof(float));
	memset(tempBuf, 0, N * sizeof(float));

	//assign a function to the JackModule::onProcess
  //In this loop audio is processed.
	jack.onProcess = [&](jack_default_audio_sample_t *inBuf, jack_default_audio_sample_t *outBuf,
    jack_nframes_t nframes) {
    // audio processing with the use of tempBuf
    fftaverage.process(inBuf, tempBuf);
    flanger.process(tempBuf, outBuf);

    // Note: these constants and dependables are chosen experimentally to map
    // openFrameworks output to a desired output of the audio processing.

    // if the value captured by osc in triggerMacro1 is larger than 10. T
    // This is done to focus on large differences in motion captured by openFrameworks
    // change lfodepth, drywet, and delay time on flanger.


    if(triggerMacro1 > 10){
      flanger.setLfoDepth(triggerMacro1*200);
      flanger.setDryWet((triggerMacro1 - 10)/10);
      flanger.setDelayTime(triggerMacro1);

    }

    // if the value captured by osc in triggermacro2 is larger than 10
    // This is done to focus on large differences in motion captured by openFrameworks
    // change the averaging size of fftAvg
    if(triggerMacro2 > 10){
      fftAvgProcess->setAmt(triggerMacro2);
    }

		return 0;
	};

	jack.autoConnect();
	//keep the program running and listen for user input, q = quit
	std::cout << "\n\nPress 'q' when you want to quit the program.\n";
	bool running = true;
	while (running)
	{
		switch (std::cin.get())
		{
			case 'q':
				running = false;
				fft->~fft1D();
				jack.end();
				break;
		}
	}

	//end the program
	return 0;
}

// error handler for osc messages
void error(int num, const char *msg, const char *path)
{
    printf("liblo server error %d in path %s: %s\n", num, path, msg);
    fflush(stdout);
}

/* catch any incoming messages and display them. returning 1 means that the
 * message has not been fully handled and the server should try other methods */
int generic_handler(const char *path, const char *types, lo_arg ** argv,
                    int argc, void *data, void *user_data)
{
		triggerMacro1 = abs(argv[0]->f);
		triggerMacro2 = abs(argv[1]->f);

    printf("\n");
    fflush(stdout);

    return 1;
}
