#include "CVAM/overlapAdd.h"

#include <iostream>

overlapAdd::overlapAdd(unsigned int buffersize, processFunction* funcObj)
{
  // we only implement 50% overlapfor convenience, so hopsize is buffer/2
  this->buffersize = buffersize;
  this->hopsize = buffersize/2;
  // create a vector bufferHistory of 3 x buffersize
  bufferHistory.resize(3*buffersize);
  std::fill(bufferHistory.begin(), bufferHistory.end(), 0.0);
  // initialize read readposition
  this->readPos = 0;
  // initialize prevResult
  prevResult.resize(buffersize - hopsize);
  std::fill(prevResult.begin(), prevResult.end(), 0.0);
  // initialize partialResult
  partialResult.resize(hopsize);
  std::fill(partialResult.begin(), partialResult.end(), 0.0);

  // initialize result
  result.resize(0);

  tempin.resize(buffersize);
  tempout.resize(buffersize);


  this->funcObj = funcObj;


  // create windowfunction
  w.resize(buffersize);
  for (unsigned int i = 0; i < buffersize; i++) {
    w.at(i) = ( 0.5 * (1 - cos(2*M_PI*i/(buffersize-1))));
  }


};

overlapAdd::~overlapAdd()
{

};

void overlapAdd::process(float* inBuf, float* outBuf)
{

  // remove first N samples of bufferHistory
  // add inBuf samples to the end of bufferHistory
  // Note: this will give the first two buffers a weird artefact, because vectors are zeros.
  bufferHistory.erase (bufferHistory.begin(),bufferHistory.begin()+buffersize);
  for (unsigned int i=0; i<buffersize; i++){
    bufferHistory.push_back(inBuf[i]);
  }

  // set readPos to after the first hop in new buffer.
  readPos = hopsize;

  // initialize result output to empty
  result.resize(0);

  // traverse through the bufferHistory in hops.
  // while readPos is smaller than or equal to buffersize it remains in the first buffer of bufferHistory.
  // if readPos > buffersize we can update the bufferHistory with a new buffer.
  while(readPos <= buffersize)
  {
     // take a frame of samples from bufferhistory and apply window.

    for(unsigned int i = 0; i < buffersize; i++){
      tempin.at(i) = bufferHistory.at(readPos+i)*w.at(i);
    }
    tempout = funcObj->process(tempin);


    //  calculate a partial buffer by taking the first part of the newly
    //  processed result and add that to the last part of the previous
    //  processed result that was stored in prevResult
    for(unsigned int i = 0; i < hopsize; i++){
      partialResult.at(i) = tempout.at(i) + prevResult.at(i);
    }
    // add the partial result at the end of the array
    result.insert(result.end(), partialResult.begin(), partialResult.end() );

    // remember  of processed for next round
    for(unsigned int i = 0; i < hopsize; i++){
      prevResult.at(i) = tempout.at(i + buffersize - hopsize);
    };

    readPos += hopsize; // next hop
  }
  for(unsigned int i = 0; i < buffersize; i++){
    outBuf[i] = tanh(2*result.at(i));
  };
};
