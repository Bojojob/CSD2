#include "CVAM/processFunction.h"
#include <iostream>
processFunction::processFunction(){};
processFunction::~processFunction(){};


// process function wrapper to take as argument for overlap add. Implement in child class.
std::vector<double> processFunction::process(std::vector<double> input){
  return input;
};
