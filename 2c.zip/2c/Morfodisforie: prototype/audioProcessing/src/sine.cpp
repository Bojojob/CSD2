#include "CVAM/sine.h"
#include "math.h"

Sine::Sine() {
  // initialize members
  amplitude = 1.0;
  sample = 0;
  phase = 0;
}



Sine::~Sine() {
}


float Sine::getSample() {
  return sample;
}

void Sine::tick() {
  // TODO - frequency / samplerate can be implemented in a more efficient way
  phase += frequency / samplerate;
  sample = sin(M_PI * 2 * phase);
}

//getters and setters
void Sine::setFrequency(float frequency)
{
  // TODO add check to see if parameter is valid
  this->frequency = frequency;
}

float Sine::getFrequency()
{
  return frequency;
}

void Sine::setSamplerate(float samplerate)
{
  this->samplerate = samplerate;
}
